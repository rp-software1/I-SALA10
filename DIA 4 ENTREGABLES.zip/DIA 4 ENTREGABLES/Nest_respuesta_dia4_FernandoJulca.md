
1) ¿Qué problema resuelve que un servicio llame a otro servicio? ¿Qué limitaciones tiene? ¿Qué pasaría si PedidosService llama a MesasService y MesasService llama de vuelta a PedidosService?

Qué problema resuelve

Ese patrón sirve para reutilizar lógica de negocio sin duplicarla.

Por ejemplo, si PedidosService necesita saber si una mesa está disponible, en vez de volver a escribir esa lógica, puede apoyarse en MesasService, que es el módulo que “sabe” trabajar con mesas.

Eso ayuda a:

mantener cada responsabilidad en su lugar
evitar código repetido
hacer el sistema más ordenado
cambiar una regla en un solo sitio

Un ejemplo simple:

MesasService se encarga de validar estados de mesa
PedidosService se encarga de crear pedidos
Entonces PedidosService puede usar lógica de MesasService cuando la necesite.

Qué limitaciones tiene

También tiene límites. Si abusas de eso, los módulos quedan muy acoplados.

Eso puede traer problemas como:

dependencias difíciles de entender
más complejidad para probar
cambios en un módulo que afectan a otro
riesgo de dependencia circular

2) Con JWT, ¿qué endpoints deberían estar protegidos y cuáles podrían ser públicos?

Endpoints que deberían estar protegidos
POST /pedidos

Debe estar protegido.

¿Por qué?

Porque crea un pedido, cambia el estado de una mesa, guarda total, items, etc.
Eso afecta directamente la operación del restaurante.

Si fuera público, cualquiera podría:

crear pedidos falsos
ocupar mesas
alterar el flujo del sistema
POST /pedidos/:id/items

Debe estar protegido.

¿Por qué?

Porque modifica un pedido existente.
Solo alguien autorizado debería poder agregar productos a una orden.

Si fuera público, cualquiera podría aumentar la cuenta de una mesa.

PATCH /pedidos/:id/estado

Debe estar protegido.

¿Por qué?

Cambiar el estado de un pedido es parte del flujo interno del negocio.

Ejemplos:

pasar de pendiente a en_preparacion
marcar lista
marcar entregada
cancelar

Eso debería hacerlo personal autorizado, no cualquier usuario.

Endpoints de Mesas que cambien datos

Por ejemplo:

crear mesa
editar mesa
cambiar estado
liberar mesa

También deben estar protegidos.

¿Por qué?

Porque las mesas representan recursos del restaurante.
No tendría sentido que cualquier persona pueda cambiar su estado.
