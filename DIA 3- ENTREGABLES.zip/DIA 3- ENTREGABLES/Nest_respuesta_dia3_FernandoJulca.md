1.Hoy construiste una máquina de estados para las mesas. En tus propias palabras, ¿qué problema resuelve ese patrón? ¿Qué pasaría si no existiera y cualquier campo pudiera cambiar a cualquier valor libremente? Usa el restaurante como ejemplo concreto.

Define reglas claras de cómo puede evolucionar el estado de una mesa (de disponible a ocupada, de reservada a ocupada, etc.).

Evita que alguien cambie arbitrariamente el estado a cualquier valor sin lógica de negocio.

Garantiza que el sistema refleje la realidad del restaurante: una mesa no puede pasar de ocupada directamente a reservada sin antes quedar disponible.

¿Qué pasaría sin ese patrón?
Imagina que cualquier campo pudiera cambiar libremente:

Un mesero podría marcar una mesa como disponible aunque todavía tenga clientes sentados.

Otra mesa podría pasar de fuera_de_servicio a ocupada sin haber sido reparada.

2.Mañana crearás PedidosModule. Cuando un mesero crea un pedido para la mesa 3, ¿qué debe pasar en el sistema? Describe la secuencia de operaciones que involucran tanto PedidosService como MesasService — sin escribir código, solo el razonamiento.

PedidosService recibe la solicitud: “crear pedido para mesa 3 con estos platos”.
PedidosService valida la mesa: consulta a MesasService.findOne(3) para verificar que la mesa existe.
Verifica el estado de la mesa:
Si la mesa está disponible o reservada, se permite crear el pedido.
Si está fuera_de_servicio, se rechaza.
Si ya está ocupada, puede agregarse un nuevo pedido solo si la lógica lo permite (ej. pedido adicional).
Crea el pedido en la base de datos: guarda el pedido con referencia a la mesa.
Actualiza el estado de la mesa:
Si estaba disponible o reservada, pasa a ocupada.
Esto lo hace MesasService.cambiarEstado(3, "ocupada"), aplicando la máquina de estados que construiste.
Devuelve la respuesta: el sistema confirma el pedido creado y muestra que la mesa ahora está ocupada.

