1.Hoy el sistema rechaza datos inválidos antes de que lleguen al controlador y retorna errores con formato consistente. Explica en tus propias palabras por qué eso es importante específicamente para un agente de IA que va a consumir esta API. ¿Qué problema concreto resuelve cada pieza: el DTO, el ValidationPipe y el ExceptionFilter?



DTO: define qué datos son válidos → evita ambigüedad (el agente sabe exactamente qué enviar).

ValidationPipe: valida antes del controlador → evita procesar datos incorrectos y devuelve errores rápidos.

ExceptionFilter: estandariza los errores → el agente puede interpretar fácilmente qué falló y cómo actuar.



2.Mañana es el último día del sprint: construyen el módulo Ticket, escriben al menos 2 tests de integración y hacen el deploy en Railway. Basándote en todo lo que construyeron esta semana, ¿qué parte del sistema crees que es más probable que falle en el deploy y por qué? ¿Qué verificarías primero?



Lo más probable es que falle la configuración del entorno en producción, sobre todo la conexión a la base de datos, variables de entorno y configuración de puertos.



Por qué: en local puede funcionar con valores fijos o archivos .env, pero en Railway todo depende de variables bien configuradas y de que la app arranque con el puerto correcto.



Primero verificaría:



variables de entorno (DATABASE\_URL, JWT\_SECRET, etc.)

conexión a la base de datos

que la app use process.env.PORT

que los imports, build y scripts de inicio funcionen en producción

