1.En Node.js con Express implementaron JWT con un middleware manual. Hoy lo hicieron con Passport, JwtStrategy y JwtAuthGuard. Describe en tus propias palabras qué ventaja concreta ofrece el enfoque de NestJS — no digas "es más organizado", da un ejemplo específico de qué problema resuelve.

En Express, el middleware manual suele estar "amarrado" a la tecnología (JWT). Si mañana el restaurante decide cambiar JWT por API Keys o OAuth (Google/Facebook), tendrías que reescribir o duplicar tus middlewares en todas las rutas.

En NestJS, la JwtStrategy resuelve el "cómo" se valida el token, mientras que el JwtAuthGuard resuelve el "qué" rutas proteger.

Ejemplo específico: Si necesitas que los administradores usen JWT pero que los mozos usen un código de acceso rápido (PIN), en Express tendrías una pesadilla de condicionales en tus middlewares. En NestJS, simplemente creas dos estrategias distintas y las aplicas con un decorador. El controlador nunca cambia; no le importa cómo se validó el usuario, solo sabe que el Guard le dio paso.

2.Mañana agregan DTOs con class-validator y manejo global de errores. Basándote en lo que tienen hoy, ¿qué datos de entrada no están siendo validados en los endpoints actuales? ¿Qué problema concreto podría causar eso en el restaurante? Da dos ejemplos reales.

Al no tener DTOs ni class-validator, tu API es "confiada": acepta cualquier JSON siempre que el formato sea válido, sin importar qué datos contenga. Esto deja la puerta abierta a que los usuarios envíen información maliciosa o basura que la base de datos procesará sin rechistar.

Aquí tienes dos problemas reales que esto causaría en el restaurante:

1. Inyección de Propiedades (Escalada de Privilegios)
Como en tu función register usas el operador spread (...userObject), el servidor guarda todo lo que recibe. Un usuario malintencionado podría enviar campos que no están en el formulario, pero sí en tu esquema de base de datos.

El problema: Un cliente podría registrarse enviando "role": "admin" en el JSON.

Consecuencia real: El sistema le daría acceso total al panel de administración, permitiéndole ver las ganancias del día, borrar pedidos o cambiar los precios de los platos para pagar menos.

2. Corrupción de Datos de Operación
Sin validación, los campos numéricos o de texto pueden recibir valores absurdos que rompen la lógica de negocio.

El problema: Al crear un nuevo plato, alguien podría enviar un "precio": -50.00 o un "nombre": "" (vacío).

Consecuencia real: Cuando el mozo intente cerrar la cuenta de una mesa que consumió ese plato, el sistema restará dinero en lugar de sumarlo, descuadrando la caja. O peor, la interfaz de la tablet de los mozos podría quedarse en blanco o dar error al intentar mostrar un plato sin nombre, deteniendo la operación en plena hora punta.
