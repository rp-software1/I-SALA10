1.Hace 8 días el restaurante no existía. Hoy tiene base de datos, autenticación, tests y configuración segura. Describe en tus propias palabras qué aprendiste que no sabías al empezar. Sé específico — no digas 'aprendí mucho', di exactamente qué.

Que Node.js + Express no solo responde rutas, sino que se organiza en routes, controllers y services (separación de responsabilidades).
Cómo MongoDB + Mongoose permite guardar datos de forma persistente, no como arrays en memoria.
Qué es un Schema y cómo valida los datos antes de guardarlos.
Cómo funciona la autenticación:
bcrypt.hash() para guardar contraseñas seguras
bcrypt.compare() para validarlas sin desencriptar
Qué es un JWT y cómo sirve para:
mantener sesión sin usar sesiones tradicionales
proteger rutas con middleware (verifyToken)
Cómo usar middlewares y por qué next() es necesario.

2.Si mañana tuvieras que agregar una nueva entidad al restaurante — por ejemplo, una tabla de pedidos — ¿qué archivos crearías, en qué orden y por qué ese orden? Describe el proceso sin escribir código.

1. Modelo (models/Order.js)
2. Service (services/orderService.js)
3. Controller (controllers/orderController.js)
4. Routes (routes/orderRoutes.js)
5. Middleware (opcional)