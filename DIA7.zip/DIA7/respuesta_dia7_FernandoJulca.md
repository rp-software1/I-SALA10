1.Un compañero dice: 'los tests son una pérdida de tiempo porque yo ya probé manualmente que funciona'. ¿Qué le responderías? Da al menos dos razones concretas basadas en lo que construyeron hoy.

- Automatización y repetibilidad: aunque hoy lo probaste manualmente y funcionó, mañana alguien cambia una línea de código y rompe la lógica sin darse cuenta. Los tests automatizados se ejecutan en segundos y garantizan que lo que ya validaste siga funcionando siempre.
- Detección de errores sutiles: en lo que construimos hoy, el error intencional pasó desapercibido en la prueba manual porque parecía correcto a simple vista. El test lo detectó inmediatamente, mostrando que no basta con “ver que funciona”, sino que necesitamos validaciones precisas.

2.Explica la diferencia entre assert.equal y assert.strictEqual usando el error intencional que encontraron hoy. ¿Por qué strictEqual es más seguro?

- assert.equal: 

*compara con igualdad no estricta (==). Eso significa que hace conversión de tipos antes de comparar. Ejemplo:
assert.equal(5, "5"); // pasa, porque convierte "5" a número

-assert.strictEqual:

*compara con igualdad estricta (===). No hace conversión de tipos, exige que valor y tipo coincidan. Ejemplo:
assert.strictEqual(5, "5"); // falla, porque número !== string

