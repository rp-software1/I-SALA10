1.Antes de hoy, un endpoint GET en Express se veía así: router.get("/platos", handler). Hoy lo hicieron con decoradores en NestJS. Describe en tus propias palabras qué cambió y por qué NestJS hace eso de esa manera. Sé específico — no digas "es diferente", explica el por qué.

En Express, un endpoint se define de forma imperativa:
router.get("/platos", handler)

En NestJS, el mismo endpoint se define con decoradores dentro de un controlador:
@Controller('platos')
export class PlatosController {
  @Get()
  obtenerPlatos() {
    return [...];
  }
}

Los decoradores permiten declarar rutas dentro de clases, agrupando endpoints relacionados en un mismo controlador.


2.El sistema del restaurante va a tener tres módulos nuevos: Mesas, Pedidos y Ticket. Basándote en lo que aprendiste hoy sobre módulos y controladores, ¿cómo organizarías esos tres módulos? ¿Qué endpoints crees que necesita cada uno? Descríbelo sin escribir código — solo la estructura y el razonamiento.

El sistema tendrá tres módulos nuevos: Mesas, Pedidos y Ticket. Cada módulo debe tener su propio controlador y servicio, con endpoints que reflejen su responsabilidad.

1. MesasModule
Responsabilidad: Gestionar las mesas del restaurante (estado, disponibilidad, asignación).
2. PedidosModule
Responsabilidad: Manejar los pedidos de los clientes.
3. TicketModule
Responsabilidad: Generar y administrar los tickets de pago.