1.Hoy el controlador dejó de tener lógica — solo delega al servicio. ¿Por qué NestJS separa de esa manera? Describe con tus propias palabras qué problema resuelve esa separación. Usa un ejemplo concreto del restaurante.

NestJS sigue el principio de separación de responsabilidades. El controlador se encarga de recibir la petición HTTP, interpretar parámetros y decidir qué servicio llamar. El servicio concentra la lógica de negocio: cálculos, validaciones, interacción con la base de datos.

Esto resuelve un problema clásico: cuando todo está en el controlador, el código se vuelve difícil de mantener y probar. Al delegar, puedes reutilizar la lógica en distintos lugares y probarla sin necesidad de simular una petición HTTP.


2.Mañana van a crear el MesasModule. Basándote en lo que hicieron hoy con Platos, describe paso a paso qué archivos crearías, en qué orden y qué haría cada uno. No escribas código — solo la estructura y el razonamiento.

el flujo sería:
Generar el módulo base

Archivo: mesas.module.ts
Crear el controlador
Crear el servicio
Definir los DTOs
Definir el esquema de Mongoose 
Integrar en el AppModule